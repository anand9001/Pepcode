# Steps 
- new folder with name using small letters and no spaces 
- npm init -y (creates a package.json file)
- npm i express (installs the express framework)





