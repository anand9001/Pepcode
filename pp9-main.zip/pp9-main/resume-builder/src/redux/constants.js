export const SET_USER = "SET_USER";
export const SET_TEMPLATE = "SET_TEMPLATE";
export const SET_DETAILS = "SET_DETAILS";
export const SAVE_START = "SAVE_START";
export const SAVE_COMPLETE = "SAVE_COMPLETE";
export const SAVE_ERR = "SAVE_ERR";
